#include "{{PROJECT_NAME}}.h"

#if defined(__ANDROID__)
#include <android/log.h>
#define LOG_TAG "{{PROJECT_NAME}}"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#else
#include <cstdio>
#define LOGI(...) printf(__VA_ARGS__)
#endif

extern "C" {

const char* {{PROJECT_NAME}}_get_greeting(void) {
    LOGI("get_greeting called");
    return "Hello from {{PROJECT_NAME}} NDK library!";
}

int {{PROJECT_NAME}}_add(int a, int b) {
    return a + b;
}

} // extern "C"