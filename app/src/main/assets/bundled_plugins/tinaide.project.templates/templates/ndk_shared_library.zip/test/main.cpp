#include "{{PROJECT_NAME}}.h"
#include <cstdio>
#include <cstring>
#include <cstdlib>

int main() {
    const char* greeting = {{PROJECT_NAME}}_get_greeting();
    printf("Greeting: %s\n", greeting);

    int result = {{PROJECT_NAME}}_add(3, 4);
    printf("3 + 4 = %d\n", result);

    if (result != 7) {
        printf("FAIL: expected 7, got %d\n", result);
        return 1;
    }

    printf("All tests passed!\n");
    return 0;
}