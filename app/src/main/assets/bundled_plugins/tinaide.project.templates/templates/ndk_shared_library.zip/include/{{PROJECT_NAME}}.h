#ifndef {{PROJECT_NAME_UPPER}}_H
#define {{PROJECT_NAME_UPPER}}_H

#if defined(_WIN32) || defined(__CYGWIN__)
  #ifdef {{PROJECT_NAME_UPPER}}_BUILDING_LIBRARY
    #ifdef __GNUC__
      #define {{PROJECT_NAME_UPPER}}_API __attribute__((dllexport))
    #else
      #define {{PROJECT_NAME_UPPER}}_API __declspec(dllexport)
    #endif
  #else
    #ifdef __GNUC__
      #define {{PROJECT_NAME_UPPER}}_API __attribute__((dllimport))
    #else
      #define {{PROJECT_NAME_UPPER}}_API __declspec(dllimport)
    #endif
  #endif
#else
  #if __GNUC__ >= 4
    #define {{PROJECT_NAME_UPPER}}_API __attribute__((visibility("default")))
  #else
    #define {{PROJECT_NAME_UPPER}}_API
  #endif
#endif

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Example exported function.
 * Returns a greeting string.
 */
{{PROJECT_NAME_UPPER}}_API const char* {{PROJECT_NAME}}_get_greeting(void);

/**
 * Example: add two integers.
 */
{{PROJECT_NAME_UPPER}}_API int {{PROJECT_NAME}}_add(int a, int b);

#ifdef __cplusplus
}
#endif

#endif // {{PROJECT_NAME_UPPER}}_H